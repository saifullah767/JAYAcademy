<?php
include("header3.php");
?>

<!doctype html>
<html lang="zxx">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/boxicons.min.css">
    <link rel="stylesheet" href="assets/css/flaticon.css">
    <link rel="stylesheet" href="assets/css/meanmenu.min.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/nice-select.min.css">
    <link rel="stylesheet" href="assets/css/odometer.min.css">
    <link rel="stylesheet" href="assets/css/date-picker.min.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.min.css">
    <link rel="stylesheet" href="assets/css/beautiful-fonts.css">
    <!-- <link rel="stylesheet" href="assets/css/style.css"> -->
    <link rel="stylesheet" href="assets/css/responsive.css">
    <link rel="icon" type="image/png" href="assets/img/Jay_Academy_90x50.png">
    <title> JAY Academy/Home </title>
</head>

<body>

    <div class="preloader">
        <div class="lds-ripple">
            <div></div>
            <div></div>
        </div>
    </div>

    <section class="eorik-slider-area">
      <div class="eorik-slider owl-carousel owl-theme">
        <div class="eorik-slider-item slider-item-bg-1" style="background-image:url(assets/img/home-one/Land001.jpg); " >
          <div class="d-table">
            <div class="d-table-cell">
              <div class="container">
                <div
                  class="
                    eorik-slider-text
                    overflow-hidden
                    one
                    eorik-slider-text-one
                  "
                >
                 
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="eorik-slider-item slider-item-bg-2" style="background-image:url(assets/img/home-one/land2.jpg)" >
          <div class="d-table">
            <div class="d-table-cell">
              <div class="container">
                <div
                  class="
                    eorik-slider-text
                    overflow-hidden
                    two
                    eorik-slider-text-one
                  "
                >
         
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="eorik-slider-item slider-item-bg-3" style="background-image:url(assets/img/home-one/land3.jpg)" >
          <div class="d-table">
            <div class="d-table-cell">
              <div class="container">
                <div
                  class="
                    eorik-slider-text
                    overflow-hidden
                    three
                    eorik-slider-text-one
                  "
                >
            
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="white-shape">
        <img src="assets/img/home-one/slider/white-shape.png" alt="Image" />
      </div>
      <div class="social-link">
        <ul>
          <li>
            <a href="#">
              <i class="bx bxl-facebook"></i>
            </a>
          </li>
          <li>
            <a href="#">
              <i class="bx bxl-twitter"></i>
            </a>
          </li>
          <li>
            <a href="#">
              <i class="bx bxl-instagram"></i>
            </a>
          </li>
        </ul>
      </div>
    </section>

    <section class="exclusive-area pt-70 ">
        <div class="container">
            <div class="section-title">
                <span>Exclusive Offers</span>
                <h2>You can get an exclusive offer </h2>
            </div>
        </div>
        <div class="container-fluid p-0">
            <div class="exclusive-top-wrap owl-carousel owl-theme">
                 <div class="exclusive-wrap">
                    <div class="row">
                        <div class="col-lg-6 pr-0">
                            <div class="exclusive-img bg-1" style="background-image:url(assets/img/home-one/EL.jpg);"  ></div>
                        </div>
                        <div class="col-lg-6 pl-0">
                            <div class="exclusive-content">
                              
                                <h3> English </h3>
                               
                                <p> The world of digital people Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis, velit similique? Voluptatum, cumque. Perspiciatis, totam. Sit, ratione! Quod dignissimos incidunt labore. Nihil omnis harum vel non quis. Sunt, volupt\ </p>
                                <ul>
                                    <li>
                                        <i class="bx bx-time"></i>
                                        Duration: 2 Months
                                    </li>
                                  
                                </ul>
                                <a href="English_Language" class="default-btn">
                                Description
                                    <i class="flaticon-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="exclusive-wrap">
                    <div class="row">
                        <div class="col-lg-6 pr-0">
                            <div class="exclusive-img bg-1" style="background-image:url(assets/img/home-one/DM.jpg)"  ></div>
                        </div>
                        <div class="col-lg-6 pl-0">
                            <div class="exclusive-content">
                             
                                <h3> Digital Marketing </h3>
                            of digital people Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis, velit similique? Voluptatum, cumque. Perspiciatis, totam. Sit, ratione! Quod dignissimos incidunt labore. Nihil omnis harum vel non quis. Sunt, volupt\ </p>
                                <ul>
                                    <li>
                                        <i class="bx bx-time"></i>
                                        Duration: 2 Months
                                    </li>
                               
                                </ul>
                                <a href="Digital_Marketing" class="default-btn">
                                Description
                                    <i class="flaticon-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div> <div class="exclusive-wrap">
                    <div class="row">
                        <div class="col-lg-6 pr-0">
                            <div class="exclusive-img bg-1" style="background-image:url(assets/img/home-one/GD.jpg)"  ></div>
                        </div>
                        <div class="col-lg-6 pl-0">
                            <div class="exclusive-content">
                               
                                <h3> Graphic Designing </h3>
                              
                                <p> The world of digital people Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis, velit similique? Voluptatum, cumque. Perspiciatis, totam. Sit, ratione! Quod dignissimos incidunt labore. Nihil omnis harum vel non quis. Sunt, volupt\ </p>
                                <ul>
                                    <li>
                                        <i class="bx bx-time"></i>
                                        Duration: 2 Months
                                    </li>
                              
                                </ul>
                                <a href="Graphic_Designing" class="default-btn">
                                Description
                                    <i class="flaticon-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div> <div class="exclusive-wrap">
                    <div class="row">
                        <div class="col-lg-6 pr-0">
                            <div class="exclusive-img bg-1" style="background-image:url(assets/img/home-one/FR.jpg)"  ></div>
                        </div>
                        <div class="col-lg-6 pl-0">
                            <div class="exclusive-content">
                     
                                <h3> Freelancing </h3>
                         
                                <p> The world of digital people Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis, velit similique? Voluptatum, cumque. Perspiciatis, totam. Sit, ratione! Quod dignissimos incidunt labore. Nihil omnis harum vel non quis. Sunt, volupt\ </p>
                                <ul>
                                    <li>
                                        <i class="bx bx-time"></i>
                                        Duration: 2 Months
                                    </li>
                         
                                </ul>
                                <a href="Freelancing" class="default-btn">
                                Description
                                    <i class="flaticon-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="exclusive-wrap">
                    <div class="row">
                        <div class="col-lg-6 pr-0">
                            <div class="exclusive-img bg-1" style="background-image:url(assets/img/home-one/WP.jpg)"  ></div>
                        </div>
                        <div class="col-lg-6 pl-0">
                            <div class="exclusive-content">
                     
                                <h3> Wordpress  </h3>
                         
                                <p> The world of digital people Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis, velit similique? Voluptatum, cumque. Perspiciatis, totam. Sit, ratione! Quod dignissimos incidunt labore. Nihil omnis harum vel non quis. Sunt, volupt\ </p>
                                <ul>
                                    <li>
                                        <i class="bx bx-time"></i>
                                        Duration: 2 Months
                                    </li>
                         
                                </ul>
                                <a href="Wordpress" class="default-btn">
                                Description
                                    <i class="flaticon-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="exclusive-wrap">
                    <div class="row">
                        <div class="col-lg-6 pr-0">
                            <div class="exclusive-img bg-1" style="background-image:url(assets/img/home-one/VA.jpg)"  ></div>
                        </div>
                        <div class="col-lg-6 pl-0">
                            <div class="exclusive-content">
                     
                                <h3> Virtual Assistant </h3>
                         
                                <p> The world of digital people Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis, velit similique? Voluptatum, cumque. Perspiciatis, totam. Sit, ratione! Quod dignissimos incidunt labore. Nihil omnis harum vel non quis. Sunt, volupt\ </p>
                                <ul>
                                    <li>
                                        <i class="bx bx-time"></i>
                                        Duration: 2 Months
                                    </li>
                         
                                </ul>
                                <a href="Virtual_Assitant" class="default-btn">
                                Description
                                    <i class="flaticon-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="exclusive-wrap">
                    <div class="row">
                        <div class="col-lg-6 pr-0">
                            <div class="exclusive-img bg-1" style="background-image:url(assets/img/home-one/MS.jpg)"  ></div>
                        </div>
                        <div class="col-lg-6 pl-0">
                            <div class="exclusive-content">
                     
                                <h3> MS Office </h3>
                         
                                <p> The world of digital people Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis, velit similique? Voluptatum, cumque. Perspiciatis, totam. Sit, ratione! Quod dignissimos incidunt labore. Nihil omnis harum vel non quis. Sunt, volupt\ </p>
                                <ul>
                                    <li>
                                        <i class="bx bx-time"></i>
                                        Duration: 2 Months
                                    </li>
                         
                                </ul>
                                <a href="MS_Office" class="default-btn">
                                Description
                                    <i class="flaticon-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                
                 <div class="exclusive-wrap">
                    <div class="row">
                        <div class="col-lg-6 pr-0">
                            <div class="exclusive-img bg-1" style="background-image:url(assets/img/home-one/IL.jpg)"  ></div>
                        </div>
                        <div class="col-lg-6 pl-0">
                            <div class="exclusive-content">
                     
                                <h3> IELTS Preparation </h3>
                         
                                <p> The world of digital people Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis, velit similique? Voluptatum, cumque. Perspiciatis, totam. Sit, ratione! Quod dignissimos incidunt labore. Nihil omnis harum vel non quis. Sunt, volupt\ </p>
                                <ul>
                                    <li>
                                        <i class="bx bx-time"></i>
                                        Duration: 2 Months
                                    </li>
                         
                                </ul>
                                <a href="IELTS" class="default-btn">
                                Description
                                    <i class="flaticon-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                
                 <div class="exclusive-wrap">
                    <div class="row">
                        <div class="col-lg-6 pr-0">
         <div class="exclusive-img bg-1" style="background-image:url(assets/img/home-one/VD.jpg)"  ></div>
                        </div>
                        <div class="col-lg-6 pl-0">
                            <div class="exclusive-content">
                     
                                <h3> Video Editing </h3>
                         
                                <p> The world of digital people Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis, velit similique? Voluptatum, cumque. Perspiciatis, totam. Sit, ratione! Quod dignissimos incidunt labore. Nihil omnis harum vel non quis. Sunt, volupt\ </p>
                                <ul>
                                    <li>
                                        <i class="bx bx-time"></i>
                                        Duration: 2 Months
                                    </li>
                         
                                </ul>
                                <a href="Video_Editing" class="default-btn">
                                Description
                                    <i class="flaticon-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                
                  <div class="exclusive-wrap">
                    <div class="row">
                        <div class="col-lg-6 pr-0">
                            <div class="exclusive-img bg-1" style="background-image:url(assets/img/home-one/AE.jpg)"  ></div>
                        </div>
                        <div class="col-lg-6 pl-0">
                            <div class="exclusive-content">
                             
                                <h3> Advanced Excel </h3>
                            of digital people Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis, velit similique? Voluptatum, cumque. Perspiciatis, totam. Sit, ratione! Quod dignissimos incidunt labore. Nihil omnis harum vel non quis. Sunt, volupt\ </p>
                                <ul>
                                    <li>
                                        <i class="bx bx-time"></i>
                                        Duration: 2 Months
                                    </li>
                               
                                </ul>
                                <a href="Advance_Excel" class="default-btn">
                                Description
                                    <i class="flaticon-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                
                
               
                    
                    
                    
              
                <!-- <div class="exclusive-wrap">
                    <div class="row">
                        <div class="col-lg-6 pr-0">
                            <div class="exclusive-img bg-2"></div>
                        </div>
                        <div class="col-lg-6 pl-0">
                            <div class="exclusive-content">
                                <span class="title">This Month Only</span>
                                <h3>$5 Breakfast package</h3>
                                <span class="review">
                                    5.0
                                    <a href="#">(580 Reviews)</a>
                                </span>
                                <p>Start $5 doller dolor sit aet odeu tur adiing elitse</p>
                                <ul>
                                    <li>
                                        <i class="bx bx-time"></i>
                                        Duration: 2Hours
                                    </li>
                                    <li>
                                        <i class="bx bx-target-lock"></i>
                                        18+ years
                                    </li>
                                </ul>
                                <a href="book-table.html" class="default-btn">
                                    Description
                                    <i class="flaticon-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div> -->
            </div>
        </div>
    </section>
<br>
<br>






   


    <div class="restaurant-item">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="row">
                        <div class="col-lg-6 content img p-0">
                            <div class="restaurant-img bg-1 jarallax">
                            </div>
                        </div>
                        <div class="col-lg-6 p-0">
                            <div class="single-restaurants">
                                <i class="restaurants-icon flaticon-maps-and-flags"></i>
                                <span>H text</span>
                                <p>Restaurant wansis dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
                                    incididunt.</p>
                            
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 p-0">
                    <div class="row">
                        <div class="col-lg-6 img p-0">
                            <div class="restaurant-img bg-2 jarallax">
                            </div>
                        </div>
                        <div class="col-lg-6 content p-0">
                            <div class="single-restaurants">
                                <i class="restaurants-icon flaticon-online-booking"></i>
                                <span>H text</span>
                                <p>Restaurant wansis dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
                                    incididunt.</p>
                               
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 p-0">
                    <div class="row">
                        <div class="col-lg-6 content p-0">
                            <div class="single-restaurants">
                                <i class="restaurants-icon flaticon-speaker"></i>
                                <span>Conference Room</span>
                                <p>Restaurant wansis dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
                                    incididunt.</p>
                            
                            </div>
                        </div>
                        <div class="col-lg-6 img p-0">
                            <div class="restaurant-img bg-3 jarallax">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="row">
                        <div class="col-lg-6 content p-0">
                            <div class="single-restaurants">
                                <i class="restaurants-icon flaticon-podium"></i>
                                <span>Best Rate</span>
                                <p>Restaurant wansis dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
                                    incididunt.</p>
                               
                            </div>
                        </div>
                        <div class="col-lg-6 img p-0">
                            <div class="restaurant-img bg-4 jarallax">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <section class="facilities-area pt-70" id="facilities" >
        <div class="container">
            <div class="section-title">
                <span>Facilities</span>
                <h2>You will get</h2>
            </div>
            <div class="row">
                <div class="booking-col-2">
                    <div class="single-facilities-wrap">
                        <div class="single-facilities">
                            <i class="facilities-icon flaticon-study"></i>
                            <h3> Daily Live Classes </h3>
                            <p>parkn ipsum dolor sit amet, consectetur adiing elit sed do eiu</p>
                          
                        </div>
                    </div>
                </div>
            
                <div class="booking-col-2">
                    <div class="single-facilities-wrap">
                        <div class="single-facilities">
                            <i class="facilities-icon flaticon-conversation"></i>
                            <h3> Teacher guidance </h3>
                            <p>parkn ipsum dolor sit amet, consectetur adiing elit sed do eiu</p>
                         
                        </div>
                    </div>
                </div>
                <div class="booking-col-2">
                    <div class="single-facilities-wrap">
                        <div class="single-facilities">
                            <i class="facilities-icon flaticon-play"></i>
                            <h3>Recorded Lectures</h3>
                            <p>parkn ipsum dolor sit amet, consectetur adiing elit sed do eiu</p>
                            
                        </div>
                    </div>
                </div>
                <div class="booking-col-2">
                    <div class="single-facilities-wrap">
                        <div class="single-facilities">
                            <i class="facilities-icon flaticon-slow"></i>
                            <h3>Internship</h3>
                            <p>parkn ipsum dolor sit amet, consectetur adiing elit sed do eiu</p>
                         
                        </div>
                    </div>
                </div>
                <div class="booking-col-2">
                    <div class="single-facilities-wrap">
                        <div class="single-facilities">
                            <i class="facilities-icon flaticon-envelope"></i>
                            <h3> Certificate </h3>
                            <p>parkn ipsum dolor sit amet, consectetur adiing elit sed do eiu</p>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


 <!--style="background-image:url(assets/img/home-one/it001.jpg)"-->
<br>
    <section class="city-view-area pt-100" style="background-image:url(assets/img/home-one/1.jpg)"  >
        <div class="container">
            <div class="city-wrap">
                <div class="single-city-item owl-carousel owl-theme">
                    <div class="city-view-single-item">
                        <div class="city-content">
                            <span>JAY ACADEMY</span>
                            <h3>digital world</h3>
                            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Consequuntur necessitatibus
                                fugit eligendi accusantium vel quos debitis cupiditate ducimus placeat explicabo
                                distinctio, consectetur eos animi, a voluptate delectus. Id, explicabo saepe
                                Consequuntur</p>
                            <p>The view onin wansis dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
                                incididunt ut labore et dolore magna aliqua. ad minim veniam, quis nostrud exercitation
                                consectetur.</p>
                        </div>
                    </div>
                    <div class="city-view-single-item">
                        <div class="city-content">
                        <span>JAY ACADEMY</span>
                            <h3>world of information technology</h3>
                            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Consequuntur necessitatibus
                                fugit eligendi accusantium vel quos debitis cupiditate ducimus placeat explicabo
                                distinctio, consectetur eos animi, a voluptate delectus. Id, explicabo saepe
                                Consequuntur</p>
                            <p>The view onin wansis dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
                                incididunt ut labore et dolore magna aliqua. ad minim veniam, quis nostrud exercitation
                                consectetur.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    

   


<br>
  
   <?php
include( "footer2.php" );
?>
    <div class="go-top">
        <i class='bx bx-chevrons-up bx-fade-up'></i>
        <i class='bx bx-chevrons-up bx-fade-up'></i>
    </div>


    <script src="assets/js/jquery.min.js"></script>

    <script src="assets/js/bootstrap.bundle.min.js"></script>

    <script src="assets/js/meanmenu.min.js"></script>

    <script src="assets/js/owl.carousel.min.js"></script>

    <script src="assets/js/wow.min.js"></script>

    <script src="assets/js/nice-select.min.js"></script>

    <script src="assets/js/magnific-popup.min.js"></script>

    <script src="assets/js/jquery.mixitup.min.js"></script>

    <script src="assets/js/appear.min.js"></script>

    <script src="assets/js/odometer.min.js"></script>

    <script src="assets/js/bootstrap-datepicker.min.js"></script>

    <script src="assets/js/ofi.min.js"></script>

    <script src="assets/js/jarallax.min.js"></script>

    <script src="assets/js/form-validator.min.js"></script>

    <script src="assets/js/contact-form-script.js"></script>

    <script src="assets/js/ajaxchimp.min.js"></script>

    <script src="assets/js/custom.js"></script>
</body>


</html>