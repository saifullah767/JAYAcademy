<footer class="footer-top-area footer-top-area-three jarallax">
        <div class="container">
            <div class="footer-middle-area pt-100 pb-70">
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="single-widget">
                            <a href="index.html">
                                <img src="assets/img/Jay_Academy_132x115.png" alt="Image">
                            </a>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quaerat molestiae corporis,
                                magni maxime perferendis ducimus.</p>
                            <ul class="social-icon">
                                <li>
                                    <a href="#">
                                        <i class="bx bxl-facebook"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="bx bxl-twitter"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="bx bxl-instagram"></i>
                                    </a>
                                </li>
                                <!-- <li>
                                    <a href="#">
                                        <i class="bx bxl-linkedin"></i>
                                    </a>
                                </li> -->
                                <li>
                                    <a href="#">
                                        <i class="bx bxl-youtube"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="single-widget">
                            <h3> Contact Us </h3>
                            <ul>
                                <li>
                                    <a href="#">
                               Mobile:   090078601
                                  
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                   
                                    Whats app: 09007601
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                       
                                   Facebook
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                     
                                       Instagram
                                    </a>
                                </li>
                             
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="single-widget">
                            <h3>Service</h3>
                        <p> All over the Pakistan </p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="single-widget">
                            <h3> Motivational Quote </h3>
                            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Provident nulla, ad dicta nemo
                                consequuntur impedit Provident amet consectetur adipisicing.</p>
                            <!-- <form class="newsletter-form" data-toggle="validator">
                                <input type="email" class="input-tracking" placeholder="Your Email" name="EMAIL"
                                    required autocomplete="off">
                                <button class="default-btn" type="submit">
                                    <i class="flaticon-right"></i>
                                </button>
                                <div id="validator-newsletter" class="form-result"></div>
                            </form> -->
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom-area mt-0">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                    
                    </div>
                    <div class="col-lg-6">
                        <div class="designed">
                            <p>Developed By  <a href="mailto:skj99667788@gmail.com"
                                    target="_blank"> SAIFULLAH </a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>