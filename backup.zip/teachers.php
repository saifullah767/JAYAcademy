
<?php
include("header3.php");
?>
<!-- <div class="page-title-area">
        
    </div> -->


    <section class="expert-team-area ptb-100 pt-135" style="padding-top: 135px;" >
        <div class="container">
            <div class="section-title">
                <span>Our Team</span>
                <h2>Our Expert Team</h2>
               
            </div>
            <div class="row">
                <div class="col-lg-4 col-sm-6">
                    <div class="single-team">
                        <img src="assets/img/team/1.jpg" alt="Image">
                        <div class="team-content">
                            <h3>Jonkin Jullinor</h3>
                            <span>Product supplier</span>
                        </div>
                        <ul>
                            <!-- <li>
                                <a href="#">
                                    <i class="bx bxl-facebook"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="bx bxl-twitter"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="bx bxl-instagram"></i>
                                </a>
                            </li> -->
                            <li>
                                <a href="#">
                                    <i class="bx bxl-linkedin"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <div class="single-team">
                        <img src="assets/img/team/2.jpg" alt="Image">
                        <div class="team-content">
                            <h3>Naimuk Waninolin</h3>
                            <span>Office executive support</span>
                        </div>
                        <ul>
                            <!-- <li>
                                <a href="#">
                                    <i class="bx bxl-facebook"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="bx bxl-twitter"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="bx bxl-instagram"></i>
                                </a>
                            </li> -->
                            <li>
                                <a href="#">
                                    <i class="bx bxl-linkedin"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <div class="single-team">
                        <img src="assets/img/team/3.jpg" alt="Image">
                        <div class="team-content">
                            <h3>Moris Julfikar</h3>
                            <span>Regional supplier</span>
                        </div>
                        <ul>
                            <!-- <li>
                                <a href="#">
                                    <i class="bx bxl-facebook"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="bx bxl-twitter"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="bx bxl-instagram"></i>
                                </a>
                            </li> -->
                            <li>
                                <a href="#">
                                    <i class="bx bxl-linkedin"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <div class="single-team">
                        <img src="assets/img/team/4.jpg" alt="Image">
                        <div class="team-content">
                            <h3>Waxin Alexgander</h3>
                            <span>CEO</span>
                        </div>
                        <ul>
                            <!-- <li>
                                <a href="#">
                                    <i class="bx bxl-facebook"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="bx bxl-twitter"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="bx bxl-instagram"></i>
                                </a>
                            </li> -->
                            <li>
                                <a href="#">
                                    <i class="bx bxl-linkedin"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <div class="single-team">
                        <img src="assets/img/team/5.jpg" alt="Image">
                        <div class="team-content">
                            <h3>Waxin Alexgander</h3>
                            <span>Founder</span>
                        </div>
                        <ul>
                            <!-- <li>
                                <a href="#">
                                    <i class="bx bxl-facebook"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="bx bxl-twitter"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="bx bxl-instagram"></i>
                                </a>
                            </li> -->
                            <li>
                                <a href="#">
                                    <i class="bx bxl-linkedin"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <div class="single-team">
                        <img src="assets/img/team/6.jpg" alt="Image">
                        <div class="team-content">
                            <h3>Waxin Alexgander</h3>
                            <span>Manager</span>
                        </div>
                        <ul>
                            <!-- <li>
                                <a href="#">
                                    <i class="bx bxl-facebook"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="bx bxl-twitter"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="bx bxl-instagram"></i>
                                </a>
                            </li> -->
                            <li>
                                <a href="#">
                                    <i class="bx bxl-linkedin"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- <div class="col-lg-12">
                    <div class="page-navigation-area">
                        <nav aria-label="Page navigation example text-center">
                            <ul class="pagination">
                                <li class="page-item">
                                    <a class="page-link page-links" href="#">
                                        <i class='bx bx-chevrons-left'></i>
                                    </a>
                                </li>
                                <li class="page-item active">
                                    <a class="page-link" href="#">1</a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#">2</a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#">3</a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#">
                                        <i class='bx bx-chevrons-right'></i>
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div> -->
            </div>
        </div>
    </section>

    <?php
include( "footer2.php" );
?>